// copia pra config.h e preenche (o config.h não vai pro git)
#pragma once

// rede Wi-Fi que a própria ESP cria. a senha precisa ter 8 caracteres ou mais
#define AP_SSID     "CultivIa"
#define AP_PASSWORD "troque-esta-senha"

// a ESP fica sempre em 192.168.4.1 e o PC que roda o docker recebe um IP dessa rede.
// o primeiro aparelho que conecta pega o .2, então conecte o PC antes dos celulares
#define MQTT_BROKER   "192.168.4.2"
#define MQTT_PORT     1883
#define MQTT_USER     "esp32"
#define MQTT_PASSWORD "mesma_do_MQTT_ESP32_PASSWORD_no_.env"
#define CLIENT_ID     "ESP32_Estufa"   // tem que ser diferente das outras placas
