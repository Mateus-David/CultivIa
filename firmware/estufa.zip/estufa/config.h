// copia pra config.h e preenche (o config.h não vai pro git)
#pragma once

// rede Wi-Fi que a própria ESP cria. a senha precisa ter 8 caracteres ou mais
#define AP_SSID     "CultivIa"
#define AP_PASSWORD "fb7cbb78e138"

// a ESP fica sempre em 192.168.4.1 e o PC que roda o docker recebe um IP dessa rede.
// o primeiro aparelho que conecta pega o .2, então conecte o PC antes dos celulares
#define MQTT_BROKER   "192.168.4.2"
#define MQTT_PORT     1883
#define MQTT_USER     "esp32"
#define MQTT_PASSWORD "fe46e2ccba0610cbbd403efb"
#define CLIENT_ID     "ESP32_Estufa"   // tem que ser diferente das outras placas
